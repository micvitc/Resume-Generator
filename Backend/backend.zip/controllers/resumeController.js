const resumeSchema = require('../models/ResumeModel.js');

global.FormData = {};

//post data into mongoDB creating new resume

module.exports.postPersonal = async (req, res, next) => {
  try {
    const { ProjectName, name, email, phoneNumber, image } = req.body;

    const exists = await resumeSchema.findOne({
      ProjectName,
      'personalDetails.name': name,
    });

    if (!exists) {
      const newResume = new resumeSchema({
        ProjectName,
        personalDetails: {
          name,
          email,
          phoneNumber,
          image,
        },
      });

      await newResume.save();

      FormData.ProjectName = ProjectName;
      FormData.personalDetails = {
        name,
        email,
        phoneNumber,
        image,
      };

      return res.status(200).json({ added: true, msg: 'added' });
    }

    return res.status(400).json({
      added: false,
      msg: 'Resume with the same ProjectName and name already exists',
    });
  } catch (err) {
    next(err);
    res.status(500).json({ message: 'Internal server error.' });
  }
};

module.exports.postAddress = async (req, res, next) => {
  try {
    const { streetAddress, city, state, zipCode, country } = req.body;

    console.log('received', streetAddress, city, state, zipCode, country);

    const resume = await resumeSchema.findOne({
      ProjectName: FormData.ProjectName,
    });
    resume.address = {
      streetAddress,
      city,
      state,
      zipCode,
      country,
    };

    await resume.save();

    res.status(200).json({ added: true, msg: 'added' });
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};

module.exports.postEducation = async (req, res, next) => {
  try {
    //
    FormData.ProjectName = 'resume2';
    //
    const { name, institute, degree, percentage, passingYear } = req.body;

    console.log(name, institute, degree, percentage, passingYear);

    const resume = await resumeSchema.findOne({
      ProjectName: FormData.ProjectName,
    });

    if (resume) {
      if (!Array.isArray(resume.education)) {
        resume.education = [];
      }
    }
    resume.education.push({
      name,
      institute,
      degree,
      percentage,
      passingYear,
    });

    await resume.save();

    res.status(200).json({ added: true, resume });
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};

module.exports.postAchievements = async (req, res, next) => {
  try {
    const { title, dateAchieve, description } = req.body;

    const resume = await resumeSchema.findOne({
      ProjectName: FormData.ProjectName,
    });

    if (resume) {
      if (!Array.isArray(resume.achievements)) {
        resume.achievements = [];
      }
    }
    resume.achievements.push({
      title,
      dateAchieve,
      description,
    });

    await resume.save();

    res.status(200).json({ added: true, resume });
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};

module.exports.postExperience = async (req, res, next) => {
  try {
    const { company, timeperiod, description } = req.body;

    const resume = await resumeSchema.findOne({
      ProjectName: FormData.ProjectName,
    });

    if (resume) {
      if (!Array.isArray(resume.workExperience)) {
        resume.workExperience = [];
      }
    }
    resume.workExperience.push({
      company,
      timeperiod,
      description,
    });

    await resume.save();

    res.status(200).json({ added: true, resume });
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};

module.exports.postProjects = async (req, res, next) => {
  try {
    const { project, duration, completionDate } = req.body;

    const resume = await resumeSchema.findOne({
      ProjectName: FormData.ProjectName,
    });

    if (resume) {
      if (!Array.isArray(resume.projects)) {
        resume.projects = [];
      }
    }
    resume.projects.push({
      project,
      duration,
      completionDate,
    });

    await resume.save();

    res.status(200).json({ added: true, resume });
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};

module.exports.postSkills = async (req, res, next) => {
  try {
    const { name } = req.body;

    const resume = await resumeSchema.findOne({
      ProjectName: FormData.ProjectName,
    });
    if (resume) {
      if (!Array.isArray(resume.skills)) {
        resume.skills = [];
      }
    }

    resume.skills.push({
      name,
    });

    await resume.save();
    res.status(200).json({ added: true, resume });
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};
//all info posted in mongoDB

//fetch all existing resumes
module.exports.getAll = async (req, res, next) => {
  try {
    const allResumes = await resumeSchema.find();
    const projectNames = allResumes.map((resume) => resume.ProjectName);
    res.status(300).json(projectNames);
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};

//fetch selected resume

module.exports.getResume = async (req, res, next) => {
  try {
    const { ProjectName } = req.body;
    const selectedResume = await resumeSchema.find({
      ProjectName: ProjectName,
    });
    res.status(300).json(selectedResume);
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};

//edit selected resume

module.exports.editSelected = async (req, res, next) => {
  try {
    const {
      ProjectName,
      FName,
      LName,
      DOB,
      Email,
      pNo,
      street,
      city,
      state,
      country,
      education,
      Skills,
    } = req.body;
    const selected = await resumeSchema.find({ ProjectName: ProjectName });
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};

//delete education

module.exports.deleteEducation = async (req, res, next) => {
  try {
    const { ProjectName, educationId } = req.body;
    const existing = await resumeSchema.find({ ProjectName: ProjectName });

    if (!existing) res.status(404).json('cannot find');

    const educationIndex = existing.education.findIndex(
      (education) => education._id.toString() === educationId
    );

    if (educationIndex === -1) res.status(404).json('cannot find education');

    existing.education.splice(educationIndex, 1);

    await existing.save();

    res.status(200).json(existing);
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};
//delete skill
module.exports.deleteSkill = async (req, res, next) => {
  try {
    const { ProjectName, skillId } = req.body;
    const existing = await resumeSchema.findOne({ ProjectName: ProjectName });

    if (!existing) res.status(404).json('cannot find');
    const skillIndex = existing.Skills.findIndex(
      (skill) => skill._id.toString() === skillId
    );

    if (skillIndex === -1) res.status(404).json('cannot find skill');

    existing.Skills.splice(skillIndex, 1);

    await existing.save();

    res.status(200).json(existing);
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};

//delete resume

module.exports.deleteSelected = async (req, res, next) => {
  try {
    const { ProjectName } = req.body;
    const exists = await resumeSchema.findOne({ ProjectName: ProjectName });
    if (!exists) res.status(404).json('resume does not exist');
    await resumeSchema.deleteOne({ ProjectName: ProjectName });
    const check = await resumeSchema.findOne({ ProjectName: ProjectName });
    if (!check) {
      res.status(200).json(`resume ${ProjectName} deleted`);
    } else {
      res.status(400).json('could not delete');
    }
  } catch (err) {
    next(err);
    res.status(500).json(err);
  }
};
